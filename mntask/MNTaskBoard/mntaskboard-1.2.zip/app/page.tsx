import MNTaskBoard from "../mntask-board"

export default function Home() {
  return <MNTaskBoard />
}
