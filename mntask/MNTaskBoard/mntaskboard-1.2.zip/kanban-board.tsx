"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DraggableTaskCard } from "./draggable-task-card"
import {
  Clock,
  Play,
  Pause,
  CheckCircle,
  Target,
  FolderOpen,
  TrendingUp,
  Crosshair,
  Filter,
  X,
  Plus,
} from "lucide-react"
import { toast } from "sonner"

interface Task {
  id: string
  title: string
  description?: string
  completed: boolean
  isFocusTask: boolean
  isPriorityFocus: boolean
  priority: "low" | "medium" | "high"
  status: "todo" | "in-progress" | "completed" | "paused"
  type: "action" | "project" | "key-result" | "objective"
  createdAt: Date
  updatedAt?: Date
  progress?: string
  category?: string
  order?: number
  tags?: string[]
  progressHistory?: Array<{
    id: string
    content: string
    timestamp: Date
    type: "progress" | "status" | "comment"
  }>
}

interface KanbanBoardProps {
  tasks: Task[]
  pendingTasks: Task[]
  onUpdateTask: (taskId: string, updates: Partial<Task>) => void
  onOpenDetails: (taskId: string) => void
  onDeleteTask: (taskId: string) => void
  onAddToFocus: (taskId: string) => void
  onAddTask?: (task: Omit<Task, "id" | "createdAt">) => void
}

type TaskTypeFilter = "all" | "action" | "project" | "key-result" | "objective"

export function KanbanBoard({
  tasks,
  pendingTasks,
  onUpdateTask,
  onOpenDetails,
  onDeleteTask,
  onAddToFocus,
  onAddTask,
}: KanbanBoardProps) {
  const [selectedFilter, setSelectedFilter] = useState<TaskTypeFilter>("all")
  const [newTaskTitle, setNewTaskTitle] = useState("")
  const [newTaskType, setNewTaskType] = useState<"action" | "project" | "key-result" | "objective">("action")
  const [showAddTask, setShowAddTask] = useState(false)

  // 合并所有任务
  const allTasks = [...tasks, ...pendingTasks]

  // 根据类型筛选任务
  const filteredTasks = selectedFilter === "all" ? allTasks : allTasks.filter((task) => task.type === selectedFilter)

  // 按状态分组任务
  const todoTasks = filteredTasks.filter((task) => task.status === "todo")
  const inProgressTasks = filteredTasks.filter((task) => task.status === "in-progress")
  const pausedTasks = filteredTasks.filter((task) => task.status === "paused")
  const completedTasks = filteredTasks.filter((task) => task.status === "completed")

  // 获取任务类型信息
  const getTypeInfo = (type: string) => {
    switch (type) {
      case "action":
        return { icon: Target, text: "动作", color: "text-blue-400" }
      case "project":
        return { icon: FolderOpen, text: "项目", color: "text-green-400" }
      case "key-result":
        return { icon: TrendingUp, text: "关键结果", color: "text-purple-400" }
      case "objective":
        return { icon: Crosshair, text: "目标", color: "text-orange-400" }
      default:
        return { icon: Target, text: "动作", color: "text-blue-400" }
    }
  }

  // 获取类型统计
  const getTypeStats = (type: TaskTypeFilter) => {
    if (type === "all") return allTasks.length
    return allTasks.filter((task) => task.type === type).length
  }

  const filterOptions: { key: TaskTypeFilter; label: string; icon: any }[] = [
    { key: "all", label: "全部", icon: Filter },
    { key: "action", label: "动作", icon: Target },
    { key: "project", label: "项目", icon: FolderOpen },
    { key: "key-result", label: "关键结果", icon: TrendingUp },
    { key: "objective", label: "目标", icon: Crosshair },
  ]

  // 添加新任务
  const handleAddTask = () => {
    if (!newTaskTitle.trim()) {
      toast.error("请输入任务标题")
      return
    }

    const newTask: Omit<Task, "id" | "createdAt"> = {
      title: newTaskTitle.trim(),
      description: "",
      completed: false,
      isFocusTask: false,
      isPriorityFocus: false,
      priority: "low",
      status: "todo",
      type: newTaskType,
      tags: [],
      progressHistory: [],
      isInPending: true,
    }

    // 如果有 onAddTask 回调，使用它；否则使用默认逻辑
    if (onAddTask) {
      onAddTask(newTask)
    }

    setNewTaskTitle("")
    setShowAddTask(false)
    toast.success(`${getTypeInfo(newTaskType).text}任务创建成功`)
  }

  // 根据当前筛选类型设置默认任务类型
  const getDefaultTaskType = (): "action" | "project" | "key-result" | "objective" => {
    if (selectedFilter === "all") return "action"
    return selectedFilter as "action" | "project" | "key-result" | "objective"
  }

  // 当筛选类型改变时，更新新任务的默认类型
  const handleFilterChange = (newFilter: TaskTypeFilter) => {
    setSelectedFilter(newFilter)
    if (newFilter !== "all") {
      setNewTaskType(newFilter as "action" | "project" | "key-result" | "objective")
    }
  }

  return (
    <div className="p-6 space-y-6">
      {/* 筛选器 */}
      <div className="flex items-center gap-4 bg-slate-800/30 rounded-lg p-4 border border-slate-700">
        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-slate-400" />
          <span className="text-white font-medium">任务类型筛选:</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {filterOptions.map((option) => {
            const IconComponent = option.icon
            const isSelected = selectedFilter === option.key
            const count = getTypeStats(option.key)

            return (
              <Button
                key={option.key}
                variant={isSelected ? "default" : "outline"}
                size="sm"
                onClick={() => handleFilterChange(option.key)}
                className={`flex items-center gap-2 ${
                  isSelected
                    ? "bg-blue-600 hover:bg-blue-700 text-white"
                    : "border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
                }`}
              >
                <IconComponent className="w-4 h-4" />
                <span>{option.label}</span>
                <Badge className="bg-slate-600/50 text-slate-300 border-0 text-xs">{count}</Badge>
              </Button>
            )
          })}
        </div>
        {selectedFilter !== "all" && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleFilterChange("all")}
            className="text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4 mr-1" />
            清除筛选
          </Button>
        )}
      </div>

      {/* 看板列 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* 待开始 */}
        <Card className="bg-slate-800/30 border-slate-700">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-slate-300">
                <Clock className="w-5 h-5 text-slate-400" />
                <span>待开始</span>
                <Badge className="bg-slate-600/50 text-slate-300 border-0">{todoTasks.length}</Badge>
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setNewTaskType(getDefaultTaskType())
                  setShowAddTask(true)
                }}
                className="h-8 w-8 p-0 text-slate-400 hover:text-white hover:bg-slate-700"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {/* 添加任务表单 */}
            {showAddTask && (
              <Card className="bg-slate-700/30 border-slate-600">
                <CardContent className="p-3 space-y-3">
                  <Input
                    value={newTaskTitle}
                    onChange={(e) => setNewTaskTitle(e.target.value)}
                    placeholder="输入任务标题..."
                    className="bg-slate-600/50 border-slate-500 text-white placeholder:text-slate-400"
                    onKeyPress={(e) => {
                      if (e.key === "Enter") {
                        handleAddTask()
                      }
                    }}
                  />
                  <div className="flex items-center gap-2">
                    <Select
                      value={newTaskType}
                      onValueChange={(value: "action" | "project" | "key-result" | "objective") =>
                        setNewTaskType(value)
                      }
                    >
                      <SelectTrigger className="bg-slate-600/50 border-slate-500 text-white text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-700">
                        <SelectItem value="action" className="text-slate-300">
                          <div className="flex items-center gap-2">
                            <Target className="w-3 h-3" />
                            动作
                          </div>
                        </SelectItem>
                        <SelectItem value="project" className="text-slate-300">
                          <div className="flex items-center gap-2">
                            <FolderOpen className="w-3 h-3" />
                            项目
                          </div>
                        </SelectItem>
                        <SelectItem value="key-result" className="text-slate-300">
                          <div className="flex items-center gap-2">
                            <TrendingUp className="w-3 h-3" />
                            关键结果
                          </div>
                        </SelectItem>
                        <SelectItem value="objective" className="text-slate-300">
                          <div className="flex items-center gap-2">
                            <Crosshair className="w-3 h-3" />
                            目标
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                    <Button
                      size="sm"
                      onClick={handleAddTask}
                      className="bg-blue-600 hover:bg-blue-700 text-white text-xs"
                    >
                      添加
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setShowAddTask(false)
                        setNewTaskTitle("")
                      }}
                      className="text-slate-400 hover:text-white text-xs"
                    >
                      取消
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {todoTasks.map((task) => (
              <DraggableTaskCard
                key={task.id}
                task={task}
                onUpdateTask={onUpdateTask}
                onOpenDetails={onOpenDetails}
                onDeleteTask={onDeleteTask}
                onAddToFocus={onAddToFocus}
              />
            ))}
            {todoTasks.length === 0 && !showAddTask && (
              <div className="text-center py-8 text-slate-400">
                <Clock className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">暂无待开始任务</p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setNewTaskType(getDefaultTaskType())
                    setShowAddTask(true)
                  }}
                  className="mt-2 text-slate-400 hover:text-white"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  添加任务
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* 进行中 */}
        <Card className="bg-slate-800/30 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-slate-300">
              <Play className="w-5 h-5 text-blue-400" />
              <span>进行中</span>
              <Badge className="bg-blue-600/20 text-blue-300 border-0">{inProgressTasks.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {inProgressTasks.map((task) => (
              <DraggableTaskCard
                key={task.id}
                task={task}
                onUpdateTask={onUpdateTask}
                onOpenDetails={onOpenDetails}
                onDeleteTask={onDeleteTask}
                onAddToFocus={onAddToFocus}
              />
            ))}
            {inProgressTasks.length === 0 && (
              <div className="text-center py-8 text-slate-400">
                <Play className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">暂无进行中任务</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* 已暂停 */}
        <Card className="bg-slate-800/30 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-slate-300">
              <Pause className="w-5 h-5 text-yellow-400" />
              <span>已暂停</span>
              <Badge className="bg-yellow-600/20 text-yellow-300 border-0">{pausedTasks.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {pausedTasks.map((task) => (
              <DraggableTaskCard
                key={task.id}
                task={task}
                onUpdateTask={onUpdateTask}
                onOpenDetails={onOpenDetails}
                onDeleteTask={onDeleteTask}
                onAddToFocus={onAddToFocus}
              />
            ))}
            {pausedTasks.length === 0 && (
              <div className="text-center py-8 text-slate-400">
                <Pause className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">暂无暂停任务</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* 已完成 */}
        <Card className="bg-slate-800/30 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-slate-300">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span>已完成</span>
              <Badge className="bg-green-600/20 text-green-300 border-0">{completedTasks.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {completedTasks.map((task) => (
              <DraggableTaskCard
                key={task.id}
                task={task}
                onUpdateTask={onUpdateTask}
                onOpenDetails={onOpenDetails}
                onDeleteTask={onDeleteTask}
                onAddToFocus={onAddToFocus}
              />
            ))}
            {completedTasks.length === 0 && (
              <div className="text-center py-8 text-slate-400">
                <CheckCircle className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">暂无已完成任务</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
