"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  MoreHorizontal,
  Target,
  FolderOpen,
  TrendingUp,
  Crosshair,
  Play,
  Pause,
  CheckCircle,
  Trash2,
  ExternalLink,
} from "lucide-react"
import { toast } from "sonner"

interface Task {
  id: string
  title: string
  description?: string
  completed: boolean
  isFocusTask: boolean
  isPriorityFocus: boolean
  priority: "low" | "medium" | "high"
  status: "todo" | "in-progress" | "completed" | "paused"
  type: "action" | "project" | "key-result" | "objective"
  createdAt: Date
  updatedAt?: Date
  progress?: string
  category?: string
  order?: number
  tags?: string[]
  progressHistory?: Array<{
    id: string
    content: string
    timestamp: Date
    type: "progress" | "status" | "comment"
  }>
}

interface DraggableTaskCardProps {
  task: Task
  onUpdateTask: (taskId: string, updates: Partial<Task>) => void
  onOpenDetails: (taskId: string) => void
  onDeleteTask: (taskId: string) => void
  onAddToFocus: (taskId: string) => void
}

export function DraggableTaskCard({
  task,
  onUpdateTask,
  onOpenDetails,
  onDeleteTask,
  onAddToFocus,
}: DraggableTaskCardProps) {
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)

  // 获取任务类型信息
  const getTypeInfo = (type: string) => {
    switch (type) {
      case "action":
        return { icon: Target, text: "动作", color: "text-blue-400" }
      case "project":
        return { icon: FolderOpen, text: "项目", color: "text-green-400" }
      case "key-result":
        return { icon: TrendingUp, text: "关键结果", color: "text-purple-400" }
      case "objective":
        return { icon: Crosshair, text: "目标", color: "text-orange-400" }
      default:
        return { icon: Target, text: "动作", color: "text-blue-400" }
    }
  }

  // 获取状态信息
  const getStatusInfo = (status: string) => {
    switch (status) {
      case "todo":
        return { text: "待开始", color: "bg-slate-600/50 text-slate-300" }
      case "in-progress":
        return { text: "进行中", color: "bg-blue-600/20 text-blue-300" }
      case "paused":
        return { text: "已暂停", color: "bg-yellow-600/20 text-yellow-300" }
      case "completed":
        return { text: "已完成", color: "bg-green-600/20 text-green-300" }
      default:
        return { text: "待开始", color: "bg-slate-600/50 text-slate-300" }
    }
  }

  // 获取优先级信息
  const getPriorityInfo = (priority: string) => {
    switch (priority) {
      case "low":
        return { text: "低", color: "bg-slate-600/50 text-slate-300" }
      case "medium":
        return { text: "中", color: "bg-yellow-600/20 text-yellow-300" }
      case "high":
        return { text: "高", color: "bg-red-600/20 text-red-300" }
      default:
        return { text: "低", color: "bg-slate-600/50 text-slate-300" }
    }
  }

  const typeInfo = getTypeInfo(task.type)
  const statusInfo = getStatusInfo(task.status)
  const priorityInfo = getPriorityInfo(task.priority)
  const TypeIcon = typeInfo.icon

  const handleStartTask = () => {
    onUpdateTask(task.id, { status: "in-progress" })
    toast.success("任务已开始")
  }

  const handlePauseTask = () => {
    onUpdateTask(task.id, { status: "paused" })
    toast.success("任务已暂停")
  }

  const handleResumeTask = () => {
    onUpdateTask(task.id, { status: "in-progress" })
    toast.success("任务已恢复")
  }

  const handleCompleteTask = () => {
    onUpdateTask(task.id, { status: "completed", completed: true })
    toast.success("任务已完成")
  }

  const handleDeleteTask = () => {
    onDeleteTask(task.id)
    setShowDeleteConfirm(false)
    toast.success("任务已删除")
  }

  const handleAddToFocus = () => {
    onAddToFocus(task.id)
    toast.success("任务已添加到焦点")
  }

  return (
    <>
      <Card className="bg-slate-800/50 border-slate-700 hover:bg-slate-700/50 transition-colors cursor-pointer group">
        <CardContent className="p-4">
          <div className="space-y-3">
            {/* 任务标题和类型 */}
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <TypeIcon className={`w-4 h-4 ${typeInfo.color} flex-shrink-0`} />
                <h3
                  className="font-medium text-white text-sm line-clamp-2 cursor-pointer hover:text-blue-300"
                  onClick={() => onOpenDetails(task.id)}
                >
                  {task.title}
                </h3>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0 text-slate-400 hover:text-white opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="bg-slate-800 border-slate-700">
                  {task.status === "todo" && (
                    <DropdownMenuItem onClick={handleStartTask} className="text-slate-300 hover:bg-slate-700">
                      <Play className="w-4 h-4 mr-2" />
                      开始任务
                    </DropdownMenuItem>
                  )}
                  {task.status === "in-progress" && (
                    <>
                      <DropdownMenuItem onClick={handlePauseTask} className="text-slate-300 hover:bg-slate-700">
                        <Pause className="w-4 h-4 mr-2" />
                        暂停任务
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={handleCompleteTask} className="text-slate-300 hover:bg-slate-700">
                        <CheckCircle className="w-4 h-4 mr-2" />
                        完成任务
                      </DropdownMenuItem>
                    </>
                  )}
                  {task.status === "paused" && (
                    <>
                      <DropdownMenuItem onClick={handleResumeTask} className="text-slate-300 hover:bg-slate-700">
                        <Play className="w-4 h-4 mr-2" />
                        恢复任务
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={handleCompleteTask} className="text-slate-300 hover:bg-slate-700">
                        <CheckCircle className="w-4 h-4 mr-2" />
                        完成任务
                      </DropdownMenuItem>
                    </>
                  )}
                  {!task.isFocusTask && (
                    <DropdownMenuItem onClick={handleAddToFocus} className="text-slate-300 hover:bg-slate-700">
                      <Target className="w-4 h-4 mr-2" />
                      加入焦点
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator className="bg-slate-600" />
                  <DropdownMenuItem
                    onClick={() => onOpenDetails(task.id)}
                    className="text-slate-300 hover:bg-slate-700"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    查看详情
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => setShowDeleteConfirm(true)}
                    className="text-red-400 hover:bg-red-900/20"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    删除任务
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {/* 状态和优先级 */}
            <div className="flex items-center gap-2">
              <Badge className={`${statusInfo.color} border-0 text-xs`}>{statusInfo.text}</Badge>
              <Badge className={`${priorityInfo.color} border-0 text-xs`}>{priorityInfo.text}</Badge>
              {task.isFocusTask && <Badge className="bg-red-500/20 text-red-300 border-0 text-xs">焦点</Badge>}
            </div>

            {/* 标签 */}
            {task.tags && task.tags.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {task.tags.slice(0, 3).map((tag) => (
                  <Badge key={tag} className="bg-slate-600/30 text-slate-300 border-0 text-xs">
                    {tag}
                  </Badge>
                ))}
                {task.tags.length > 3 && (
                  <Badge className="bg-slate-600/30 text-slate-300 border-0 text-xs">+{task.tags.length - 3}</Badge>
                )}
              </div>
            )}

            {/* 创建时间 */}
            <div className="text-xs text-slate-400">{new Date(task.createdAt).toLocaleDateString()}</div>
          </div>
        </CardContent>
      </Card>

      {/* 删除确认对话框 */}
      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent className="bg-slate-800 border-slate-700">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">确认删除任务</AlertDialogTitle>
            <AlertDialogDescription className="text-slate-300">
              确定要删除任务 "{task.title}" 吗？此操作无法撤销。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-slate-700 text-slate-300 border-slate-600 hover:bg-slate-600">
              取消
            </AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteTask} className="bg-red-600 text-white hover:bg-red-700">
              删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
