"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { MoreVertical, Trash2, Target, Play, Pause, Square, RotateCcw, Plus } from "lucide-react"

interface Task {
  id: string
  title: string
  description?: string
  completed: boolean
  isFocusTask: boolean
  isPriorityFocus: boolean
  priority: "low" | "medium" | "high"
  status: "todo" | "in-progress" | "completed" | "paused"
  type: "action" | "project" | "key-result" | "objective"
  createdAt: Date
  updatedAt?: Date
  progress?: string
  category?: string
  order?: number
  tags?: string[]
  progressHistory?: Array<{
    id: string
    content: string
    timestamp: Date
    type: "progress" | "status" | "comment"
  }>
}

interface DraggableTaskCardProps {
  task: Task
  onUpdateTask: (taskId: string, updates: Partial<Task>) => void
  onOpenDetails: (taskId: string) => void
  onDeleteTask: (taskId: string) => void
  onAddToFocus: (taskId: string) => void
}

// 预定义的标签颜色
const tagColors = [
  "bg-red-500/20 text-red-300 border-red-500/30",
  "bg-blue-500/20 text-blue-300 border-blue-500/30",
  "bg-green-500/20 text-green-300 border-green-500/30",
  "bg-yellow-500/20 text-yellow-300 border-yellow-500/30",
  "bg-purple-500/20 text-purple-300 border-purple-500/30",
  "bg-pink-500/20 text-pink-300 border-pink-500/30",
  "bg-indigo-500/20 text-indigo-300 border-indigo-500/30",
  "bg-orange-500/20 text-orange-300 border-orange-500/30",
  "bg-teal-500/20 text-teal-300 border-teal-500/30",
  "bg-cyan-500/20 text-cyan-300 border-cyan-500/30",
]

// 根据标签名称生成一致的颜色
const getTagColor = (tag: string): string => {
  const hash = tag.split("").reduce((a, b) => {
    a = (a << 5) - a + b.charCodeAt(0)
    return a & a
  }, 0)
  return tagColors[Math.abs(hash) % tagColors.length]
}

export function DraggableTaskCard({
  task,
  onUpdateTask,
  onOpenDetails,
  onDeleteTask,
  onAddToFocus,
}: DraggableTaskCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "todo":
        return "bg-slate-600 text-slate-300"
      case "in-progress":
        return "bg-blue-600 text-blue-100"
      case "paused":
        return "bg-yellow-600 text-yellow-100"
      case "completed":
        return "bg-green-600 text-green-100"
      default:
        return "bg-slate-600 text-slate-300"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "low":
        return "bg-slate-600 text-slate-300"
      case "medium":
        return "bg-yellow-600 text-yellow-100"
      case "high":
        return "bg-red-600 text-red-100"
      default:
        return "bg-slate-600 text-slate-300"
    }
  }

  const getTypeInfo = (type: string) => {
    switch (type) {
      case "action":
        return { emoji: "⚡️", text: "动作" }
      case "project":
        return { emoji: "📁", text: "项目" }
      case "key-result":
        return { emoji: "📈", text: "关键结果" }
      case "objective":
        return { emoji: "🎯", text: "目标" }
      default:
        return { emoji: "⚡️", text: "动作" }
    }
  }

  const typeInfo = getTypeInfo(task.type)

  const handleStatusChange = (newStatus: "todo" | "in-progress" | "completed" | "paused") => {
    onUpdateTask(task.id, {
      status: newStatus,
      completed: newStatus === "completed",
    })
  }

  const handleAddProgress = () => {
    const progress = prompt("请输入进展内容:")
    if (progress?.trim()) {
      // 这里需要调用添加进展的函数，但当前接口没有提供
      // 可以通过 onUpdateTask 来更新进展
      const newProgressEntry = {
        id: Date.now().toString(),
        content: progress.trim(),
        timestamp: new Date(),
        type: "progress" as const,
      }

      onUpdateTask(task.id, {
        progress: progress.trim(),
        progressHistory: [...(task.progressHistory || []), newProgressEntry],
        updatedAt: new Date(),
      })
    }
  }

  return (
    <Card
      className={`bg-slate-700/30 border-slate-600 hover:bg-slate-700/50 transition-all duration-200 cursor-pointer ${
        task.isPriorityFocus ? "ring-2 ring-orange-500/60 shadow-lg shadow-orange-500/20" : ""
      }`}
      onClick={() => onOpenDetails(task.id)}
    >
      <CardContent className="p-3">
        {/* 顶部徽章行 */}
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1 flex-wrap">
            {/* 任务类型徽章 */}
            <Badge className="bg-slate-600/50 text-slate-300 border-slate-500 text-xs">
              <span className="mr-1">{typeInfo.emoji}</span>
              {typeInfo.text}
            </Badge>

            {/* 优先级徽章 */}
            <Badge className={`${getPriorityColor(task.priority)} border-0 text-xs`}>
              {task.priority === "low" ? "低" : task.priority === "medium" ? "中" : "高"}
            </Badge>

            {task.isFocusTask && (
              <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30 text-xs">焦点</Badge>
            )}
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
              <Button variant="ghost" size="sm" className="p-1 h-6 w-6 text-slate-400 hover:text-white">
                <MoreVertical className="w-3 h-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-slate-800 border-slate-700">
              {/* 状态切换选项 */}
              {task.status === "todo" && (
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation()
                    handleStatusChange("in-progress")
                  }}
                  className="text-slate-300 hover:bg-slate-700"
                >
                  <Play className="w-4 h-4 mr-2" />
                  开始任务
                </DropdownMenuItem>
              )}

              {task.status === "in-progress" && (
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation()
                    handleStatusChange("paused")
                  }}
                  className="text-slate-300 hover:bg-slate-700"
                >
                  <Pause className="w-4 h-4 mr-2" />
                  暂停任务
                </DropdownMenuItem>
              )}

              {task.status === "paused" && (
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation()
                    handleStatusChange("in-progress")
                  }}
                  className="text-slate-300 hover:bg-slate-700"
                >
                  <Play className="w-4 h-4 mr-2" />
                  继续任务
                </DropdownMenuItem>
              )}

              {(task.status === "in-progress" || task.status === "paused") && (
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation()
                    handleStatusChange("completed")
                  }}
                  className="text-slate-300 hover:bg-slate-700"
                >
                  <Square className="w-4 h-4 mr-2" />
                  完成任务
                </DropdownMenuItem>
              )}

              {task.status === "completed" && (
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation()
                    handleStatusChange("todo")
                  }}
                  className="text-slate-300 hover:bg-slate-700"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  重新开始
                </DropdownMenuItem>
              )}

              {!task.isFocusTask && (
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation()
                    onAddToFocus(task.id)
                  }}
                  className="text-slate-300 hover:bg-slate-700"
                >
                  <Target className="w-4 h-4 mr-2" />
                  加入焦点
                </DropdownMenuItem>
              )}

              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation()
                  onDeleteTask(task.id)
                }}
                className="text-red-400 hover:bg-red-900/20"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                删除任务
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* 任务标题 */}
        <h3 className="text-white font-medium mb-2 line-clamp-2 leading-relaxed text-sm">{task.title}</h3>

        {/* 标签显示 */}
        {task.tags && task.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-2">
            {task.tags.slice(0, 2).map((tag, index) => (
              <Badge key={index} className={`${getTagColor(tag)} border text-xs px-1.5 py-0.5`}>
                {tag}
              </Badge>
            ))}
            {task.tags.length > 2 && (
              <Badge className="bg-slate-600/50 text-slate-400 border-slate-600 text-xs px-1.5 py-0.5">
                +{task.tags.length - 2}
              </Badge>
            )}
          </div>
        )}

        {/* 路径信息 */}
        {task.category && <p className="text-xs text-slate-400 mb-2 truncate">{task.category}</p>}

        {/* 任务描述 */}
        {task.description && (
          <div className="mb-2 p-2 bg-slate-600/30 rounded border-l-2 border-slate-500">
            <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed italic">{task.description}</p>
          </div>
        )}

        {/* 最新进展 */}
        {task.progress && (
          <div className="mb-2 p-2 bg-blue-900/20 rounded border-l-2 border-blue-500">
            <div className="flex items-center gap-1 mb-1">
              <div className="w-1.5 h-1.5 bg-blue-400 rounded-full"></div>
              <span className="text-xs text-blue-300 font-medium">最近进展</span>
            </div>
            <p className="text-xs text-slate-300 line-clamp-2">{task.progress}</p>
          </div>
        )}

        {/* 底部操作按钮 */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-600">
          <div className="text-xs text-slate-400">{new Date(task.createdAt).toLocaleDateString("zh-CN")}</div>

          <div className="flex items-center gap-1">
            {/* 添加进展按钮 */}
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation()
                handleAddProgress()
              }}
              className="p-1 h-6 w-6 text-slate-400 hover:text-blue-400 hover:bg-blue-900/20"
              title="添加进展"
            >
              <Plus className="w-3 h-3" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
