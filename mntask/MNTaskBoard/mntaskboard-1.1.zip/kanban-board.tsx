"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { DraggableTaskCard } from "./draggable-task-card"
import { Clock, Play, Pause, CheckCircle, Target, FolderOpen, TrendingUp, Crosshair, Filter, X } from "lucide-react"

interface Task {
  id: string
  title: string
  description?: string
  completed: boolean
  isFocusTask: boolean
  isPriorityFocus: boolean
  priority: "low" | "medium" | "high"
  status: "todo" | "in-progress" | "completed" | "paused"
  type: "action" | "project" | "key-result" | "objective"
  createdAt: Date
  updatedAt?: Date
  progress?: string
  category?: string
  order?: number
  tags?: string[]
  progressHistory?: Array<{
    id: string
    content: string
    timestamp: Date
    type: "progress" | "status" | "comment"
  }>
}

interface KanbanBoardProps {
  tasks: Task[]
  pendingTasks: Task[]
  onUpdateTask: (taskId: string, updates: Partial<Task>) => void
  onOpenDetails: (taskId: string) => void
  onDeleteTask: (taskId: string) => void
  onAddToFocus: (taskId: string) => void
}

type TaskTypeFilter = "all" | "action" | "project" | "key-result" | "objective"

export function KanbanBoard({
  tasks,
  pendingTasks,
  onUpdateTask,
  onOpenDetails,
  onDeleteTask,
  onAddToFocus,
}: KanbanBoardProps) {
  const [selectedFilter, setSelectedFilter] = useState<TaskTypeFilter>("all")

  // 合并所有任务
  const allTasks = [...tasks, ...pendingTasks]

  // 根据类型筛选任务
  const filteredTasks = selectedFilter === "all" ? allTasks : allTasks.filter((task) => task.type === selectedFilter)

  // 按状态分组任务
  const todoTasks = filteredTasks.filter((task) => task.status === "todo")
  const inProgressTasks = filteredTasks.filter((task) => task.status === "in-progress")
  const pausedTasks = filteredTasks.filter((task) => task.status === "paused")
  const completedTasks = filteredTasks.filter((task) => task.status === "completed")

  // 获取任务类型信息
  const getTypeInfo = (type: string) => {
    switch (type) {
      case "action":
        return { icon: Target, text: "动作", color: "text-blue-400" }
      case "project":
        return { icon: FolderOpen, text: "项目", color: "text-green-400" }
      case "key-result":
        return { icon: TrendingUp, text: "关键结果", color: "text-purple-400" }
      case "objective":
        return { icon: Crosshair, text: "目标", color: "text-orange-400" }
      default:
        return { icon: Target, text: "动作", color: "text-blue-400" }
    }
  }

  // 获取类型统计
  const getTypeStats = (type: TaskTypeFilter) => {
    if (type === "all") return allTasks.length
    return allTasks.filter((task) => task.type === type).length
  }

  const filterOptions: { key: TaskTypeFilter; label: string; icon: any }[] = [
    { key: "all", label: "全部", icon: Filter },
    { key: "action", label: "动作", icon: Target },
    { key: "project", label: "项目", icon: FolderOpen },
    { key: "key-result", label: "关键结果", icon: TrendingUp },
    { key: "objective", label: "目标", icon: Crosshair },
  ]

  return (
    <div className="p-6 space-y-6">
      {/* 筛选器 */}
      <div className="flex items-center gap-4 bg-slate-800/30 rounded-lg p-4 border border-slate-700">
        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-slate-400" />
          <span className="text-white font-medium">任务类型筛选:</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {filterOptions.map((option) => {
            const IconComponent = option.icon
            const isSelected = selectedFilter === option.key
            const count = getTypeStats(option.key)

            return (
              <Button
                key={option.key}
                variant={isSelected ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedFilter(option.key)}
                className={`flex items-center gap-2 ${
                  isSelected
                    ? "bg-blue-600 hover:bg-blue-700 text-white"
                    : "border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
                }`}
              >
                <IconComponent className="w-4 h-4" />
                <span>{option.label}</span>
                <Badge className="bg-slate-600/50 text-slate-300 border-0 text-xs">{count}</Badge>
              </Button>
            )
          })}
        </div>
        {selectedFilter !== "all" && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSelectedFilter("all")}
            className="text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4 mr-1" />
            清除筛选
          </Button>
        )}
      </div>

      {/* 看板列 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* 待开始 */}
        <Card className="bg-slate-800/30 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-slate-300">
              <Clock className="w-5 h-5 text-slate-400" />
              <span>待开始</span>
              <Badge className="bg-slate-600/50 text-slate-300 border-0">{todoTasks.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {todoTasks.map((task) => (
              <DraggableTaskCard
                key={task.id}
                task={task}
                onUpdateTask={onUpdateTask}
                onOpenDetails={onOpenDetails}
                onDeleteTask={onDeleteTask}
                onAddToFocus={onAddToFocus}
              />
            ))}
            {todoTasks.length === 0 && (
              <div className="text-center py-8 text-slate-400">
                <Clock className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">暂无待开始任务</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* 进行中 */}
        <Card className="bg-slate-800/30 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-slate-300">
              <Play className="w-5 h-5 text-blue-400" />
              <span>进行中</span>
              <Badge className="bg-blue-600/20 text-blue-300 border-0">{inProgressTasks.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {inProgressTasks.map((task) => (
              <DraggableTaskCard
                key={task.id}
                task={task}
                onUpdateTask={onUpdateTask}
                onOpenDetails={onOpenDetails}
                onDeleteTask={onDeleteTask}
                onAddToFocus={onAddToFocus}
              />
            ))}
            {inProgressTasks.length === 0 && (
              <div className="text-center py-8 text-slate-400">
                <Play className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">暂无进行中任务</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* 已暂停 */}
        <Card className="bg-slate-800/30 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-slate-300">
              <Pause className="w-5 h-5 text-yellow-400" />
              <span>已暂停</span>
              <Badge className="bg-yellow-600/20 text-yellow-300 border-0">{pausedTasks.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {pausedTasks.map((task) => (
              <DraggableTaskCard
                key={task.id}
                task={task}
                onUpdateTask={onUpdateTask}
                onOpenDetails={onOpenDetails}
                onDeleteTask={onDeleteTask}
                onAddToFocus={onAddToFocus}
              />
            ))}
            {pausedTasks.length === 0 && (
              <div className="text-center py-8 text-slate-400">
                <Pause className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">暂无暂停任务</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* 已完成 */}
        <Card className="bg-slate-800/30 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-slate-300">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span>已完成</span>
              <Badge className="bg-green-600/20 text-green-300 border-0">{completedTasks.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {completedTasks.map((task) => (
              <DraggableTaskCard
                key={task.id}
                task={task}
                onUpdateTask={onUpdateTask}
                onOpenDetails={onOpenDetails}
                onDeleteTask={onDeleteTask}
                onAddToFocus={onAddToFocus}
              />
            ))}
            {completedTasks.length === 0 && (
              <div className="text-center py-8 text-slate-400">
                <CheckCircle className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">暂无已完成任务</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
